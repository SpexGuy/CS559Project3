#pragma once

/* checks for a GL error and prints it */
bool checkError(char *s);
